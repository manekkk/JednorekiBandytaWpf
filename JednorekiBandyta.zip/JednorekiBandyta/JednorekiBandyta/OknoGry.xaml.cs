﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace JednorekiBandyta
{
    public partial class OknoGry : Window
    {
        private int kasa;
        private int aktualnaStawka;
        private Random random = new Random();
        private DispatcherTimer timer;
        private int anim;
        private int[] sym = new int[3];
        private MediaPlayer spinSound = new MediaPlayer(); // dzwiek kręcenia

        private string[] sciezki = {
            "s1.png",
            "s2.png",
            "s3.png",
            "s4.png",
            "s5.png"
        };

        public OknoGry(int startKasa){
            InitializeComponent();
            kasa = startKasa;
            UpdateInfo();

            // ladowanie dzwieku
            spinSound.Open(new Uri("spin.mp3", UriKind.Relative));
        }

        private void UpdateInfo(){
            KasaText.Text = $"Pieniądze: {kasa} zł";
        }

        private void Losuj_Click(object sender, RoutedEventArgs e){
            if (!int.TryParse(StawkaBox.Text, out int stawka) || stawka <= 0){
                MessageBox.Show("Podaj poprawną stawkę.");
                return;
            }

            if (kasa < stawka){
                MessageBox.Show("Nie masz tyle pieniędzy!");
                return;
            }

            aktualnaStawka = stawka;
            kasa -= stawka;
            UpdateInfo();
            Losuj.IsEnabled = false;
            StartAnim();
        }

        private void StartAnim(){
            anim = 0;
            // dzwiek krecenia jeden raz
            spinSound.Position = TimeSpan.Zero;
            spinSound.Play();

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(60);
            timer.Tick += Tick;
            timer.Start();
        }

        private void Tick(object sender, EventArgs e){
            for (int i = 0; i < 3; i++)
                sym[i] = random.Next(0, sciezki.Length);

            B1.Source = new BitmapImage(new Uri(sciezki[sym[0]], UriKind.Relative));
            B2.Source = new BitmapImage(new Uri(sciezki[sym[1]], UriKind.Relative));
            B3.Source = new BitmapImage(new Uri(sciezki[sym[2]], UriKind.Relative));

            anim++;

            if (anim >= 20){
                timer.Stop();
                Wynik();
            }
        }

        private void Wynik(){
            // zatrzymanie dzwieku
            spinSound.Stop();

            bool trzy = sym[0] == sym[1] && sym[1] == sym[2];
            bool dwa = sym[0] == sym[1] || sym[1] == sym[2] || sym[0] == sym[2];

            if (trzy){
                int wygrana = aktualnaStawka * 15;
                kasa += wygrana;
                WygranaText.Text = $"TRZY TAKIE SAME! +{wygrana} zł";
            }
            else if (dwa){
                int wygrana = (int)(aktualnaStawka * 0.8);
                kasa += wygrana;
                WygranaText.Text = $"DWA TAKIE SAME! +{wygrana} zł";
            }
            else{
                WygranaText.Text = $"Brak wygranej";
            }

            Losuj.IsEnabled = true;
            UpdateInfo();
        }
    }
}
